import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { LogIn, SkipForward, ChevronRight } from "lucide-react";
import { OnboardingSlide } from "./components/OnboardingSlide";
import { CircleNetworkIllustration } from "./components/CircleNetworkIllustration";
import { SecureLoginIllustration } from "./components/SecureLoginIllustration";
import { DigitalCardIllustration } from "./components/DigitalCardIllustration";
import { Button } from "./components/ui/button";
import logo from "figma:asset/be87c11bba7a2041c6a6fdd0201f6a4882e4c5b4.png";

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      illustration: <CircleNetworkIllustration />,
      title: "Selamat Datang di Official.id",
      description: "Solusi berjejaring mudah di dalam circle dan antara circle yang lain",
    },
    {
      illustration: <SecureLoginIllustration />,
      title: "Pendaftaran Mudah & Aman",
      description: "Pendaftaran mudah dan aman dengan Google dan LinkedIn",
    },
    {
      illustration: <DigitalCardIllustration />,
      title: "Kartu Nama Digital Pintar",
      description: "Bagikan kartu nama digital pintar dengan mudah",
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const handleSkip = () => {
    setCurrentSlide(slides.length - 1);
  };

  const handleLogin = () => {
    console.log("Login clicked");
    // Handle login action
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col">
      {/* Logo */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="pt-8 pb-4 px-6 flex justify-center"
      >
        <img src={logo} alt="Official.id Logo" className="h-16 w-16" />
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-4">
        <div className="w-full max-w-2xl">
          {/* Slides Container */}
          <AnimatePresence mode="wait">
            <OnboardingSlide
              key={currentSlide}
              illustration={slides[currentSlide].illustration}
              title={slides[currentSlide].title}
              description={slides[currentSlide].description}
            />
          </AnimatePresence>

          {/* Progress Indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="flex justify-center gap-2 mt-12"
          >
            {slides.map((_, index) => (
              <motion.div
                key={index}
                className={`h-2 rounded-full transition-all duration-300 ${
                  index === currentSlide
                    ? "bg-teal-600 w-8"
                    : "bg-gray-300 w-2"
                }`}
                whileHover={{ scale: 1.2 }}
                onClick={() => setCurrentSlide(index)}
                style={{ cursor: "pointer" }}
              />
            ))}
          </motion.div>
        </div>
      </div>

      {/* Action Buttons */}
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="pb-8 px-6 flex justify-center gap-4"
      >
        {/* Login Button */}
        <Button
          onClick={handleLogin}
          variant="outline"
          className="flex items-center gap-2"
        >
          <LogIn className="w-4 h-4" />
          Login
        </Button>

        {/* Skip Button - Only show if not on last slide */}
        {currentSlide < slides.length - 1 && (
          <Button
            onClick={handleSkip}
            variant="ghost"
            className="flex items-center gap-2"
          >
            <SkipForward className="w-4 h-4" />
            Skip
          </Button>
        )}

        {/* Next Button */}
        <Button
          onClick={handleNext}
          disabled={currentSlide === slides.length - 1}
          className="flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white"
        >
          Next
          <ChevronRight className="w-4 h-4" />
        </Button>
      </motion.div>
    </div>
  );
}
