
  # New Business Card Templates

  This is a code bundle for New Business Card Templates. The original project is available at https://www.figma.com/design/RtnWWi2tl0FpGLDwuKJKaB/New-Business-Card-Templates.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  