import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { MMBatch8Card, KabayanGroupCard, MickeyCard, BettyBoopCard, FelixTheCatCard } from './NewCardTemplates';

interface BusinessCard {
  full_name: string;
  job_title?: string;
  company?: string;
  business_description?: string;
  email: string;
  phone?: string;
  website?: string;
  address?: string;
  city?: string;
  profile_photo_url?: string;
  show_business_description?: boolean;
}

const CardViewer: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [translateX, setTranslateX] = useState(0);
  const sliderRef = useRef<HTMLDivElement>(null);

  // Sample data untuk demo
  const sampleCard: BusinessCard = {
    full_name: 'John Doe',
    job_title: 'Senior Designer',
    company: 'Creative Agency',
    business_description: 'Passionate about creating beautiful and functional designs that make a difference.',
    email: 'john.doe@example.com',
    phone: '+62 812 3456 7890',
    website: 'https://johndoe.com',
    address: 'Jl. Raya Bandung No. 123',
    city: 'Bandung',
    profile_photo_url: '',
    show_business_description: true,
  };

  const visibleFields = {
    email: true,
    phone: true,
    website: true,
    address: true,
    city: true,
    social_links: true,
  };

  const socialLinks = {
    linkedin: 'https://linkedin.com/in/johndoe',
    twitter: 'https://twitter.com/johndoe',
    instagram: 'https://instagram.com/johndoe',
  };

  const handleGenerateVCard = () => {
    console.log('Generate vCard');
    alert('Fitur download vCard akan segera tersedia!');
  };

  const templates = [
    {
      name: 'MM Batch 8 ITHB',
      component: (
        <MMBatch8Card
          card={sampleCard}
          visibleFields={visibleFields}
          socialLinks={socialLinks}
          onGenerateVCard={handleGenerateVCard}
        />
      ),
    },
    {
      name: 'Kabayan Group',
      component: (
        <KabayanGroupCard
          card={sampleCard}
          visibleFields={visibleFields}
          socialLinks={socialLinks}
          onGenerateVCard={handleGenerateVCard}
        />
      ),
    },
    {
      name: 'Mickey Mouse',
      component: (
        <MickeyCard
          card={sampleCard}
          visibleFields={visibleFields}
          socialLinks={socialLinks}
          onGenerateVCard={handleGenerateVCard}
        />
      ),
    },
    {
      name: 'Betty Boop',
      component: (
        <BettyBoopCard
          card={sampleCard}
          visibleFields={visibleFields}
          socialLinks={socialLinks}
          onGenerateVCard={handleGenerateVCard}
        />
      ),
    },
    {
      name: 'Felix The Cat',
      component: (
        <FelixTheCatCard
          card={sampleCard}
          visibleFields={visibleFields}
          socialLinks={socialLinks}
          onGenerateVCard={handleGenerateVCard}
        />
      ),
    },
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % templates.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + templates.length) % templates.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  // Touch/Mouse drag handlers
  const handleDragStart = (clientX: number) => {
    setIsDragging(true);
    setStartX(clientX);
  };

  const handleDragMove = (clientX: number) => {
    if (!isDragging) return;
    const diff = clientX - startX;
    setTranslateX(diff);
  };

  const handleDragEnd = () => {
    if (!isDragging) return;
    setIsDragging(false);

    // If dragged more than 100px, change slide
    if (translateX > 100) {
      prevSlide();
    } else if (translateX < -100) {
      nextSlide();
    }

    setTranslateX(0);
  };

  // Mouse events
  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    handleDragStart(e.clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    handleDragMove(e.clientX);
  };

  const handleMouseUp = () => {
    handleDragEnd();
  };

  const handleMouseLeave = () => {
    if (isDragging) {
      handleDragEnd();
    }
  };

  // Touch events
  const handleTouchStart = (e: React.TouchEvent) => {
    handleDragStart(e.touches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    handleDragMove(e.touches[0].clientX);
  };

  const handleTouchEnd = () => {
    handleDragEnd();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-purple-50 to-pink-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">
            Business Card Templates
          </h1>
          <p className="text-gray-600 text-lg">
            Swipe atau gunakan panah untuk melihat template lainnya
          </p>
          <div className="mt-4 flex items-center justify-center gap-2">
            <span className="text-sm font-medium text-gray-700">
              Template {currentSlide + 1} dari {templates.length}:
            </span>
            <span className="text-sm font-bold text-purple-600">
              {templates[currentSlide].name}
            </span>
          </div>
        </div>

        {/* Slider */}
        <div className="relative px-4 sm:px-16 mb-16">
          {/* Prev Arrow */}
          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center text-gray-700 hover:bg-purple-600 hover:text-white transition-all transform hover:scale-110 hidden sm:flex"
            aria-label="Previous template"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Slider Container */}
          <div
            ref={sliderRef}
            className="overflow-hidden cursor-grab active:cursor-grabbing"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseLeave}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
          >
            <div
              className="flex transition-transform duration-300 ease-out"
              style={{
                transform: `translateX(calc(-${currentSlide * 100}% + ${translateX}px))`,
              }}
            >
              {templates.map((template, index) => (
                <div
                  key={index}
                  className="w-full flex-shrink-0 px-4"
                  style={{ pointerEvents: isDragging ? 'none' : 'auto' }}
                >
                  <div className="flex justify-center">
                    {template.component}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Next Arrow */}
          <button
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center text-gray-700 hover:bg-purple-600 hover:text-white transition-all transform hover:scale-110 hidden sm:flex"
            aria-label="Next template"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Dots Navigation */}
          <div className="flex justify-center gap-2 mt-8">
            {templates.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentSlide
                    ? 'bg-purple-600 w-8'
                    : 'bg-purple-300 hover:bg-purple-400'
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>

        {/* Template Info */}
        <div className="mt-12 bg-white rounded-xl shadow-lg p-6 max-w-2xl mx-auto">
          <h3 className="text-xl font-bold text-gray-900 mb-4">
            Tentang Template {templates[currentSlide].name}
          </h3>
          <div className="text-gray-700 space-y-2">
            {currentSlide === 0 && (
              <p>
                <strong>MM Batch 8 ITHB:</strong> Template profesional dengan warna navy blue dan gold yang elegan.
                Cocok untuk keperluan bisnis formal dan networking profesional.
              </p>
            )}
            {currentSlide === 1 && (
              <p>
                <strong>Kabayan Group:</strong> Template kreatif dan penuh semangat dengan warna kuning dan hitam.
                Sempurna untuk brand yang energik dan dinamis.
              </p>
            )}
            {currentSlide === 2 && (
              <p>
                <strong>Mickey Mouse:</strong> Template vintage Disney dengan tema grayscale yang klasik.
                Memberikan kesan nostalgia dan timeless untuk kartu bisnis Anda.
              </p>
            )}
            {currentSlide === 3 && (
              <p>
                <strong>Betty Boop:</strong> Template vintage cartoon dengan warna pink, red, dan peach.
                Cocok untuk brand yang fun, feminin, dan penuh karakter.
              </p>
            )}
            {currentSlide === 4 && (
              <p>
                <strong>Felix The Cat:</strong> Template klasik hitam putih dengan aksen merah.
                Design bold dan striking untuk kesan profesional yang memorable.
              </p>
            )}
          </div>
        </div>

        {/* Instructions */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-4 bg-white rounded-full px-6 py-3 shadow-md">
            <div className="flex items-center gap-2">
              <span className="text-2xl">👆</span>
              <span className="text-sm text-gray-600">Swipe</span>
            </div>
            <div className="w-px h-6 bg-gray-300"></div>
            <div className="flex items-center gap-2">
              <ChevronLeft className="w-4 h-4 text-gray-600" />
              <ChevronRight className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-600">Navigate</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardViewer;