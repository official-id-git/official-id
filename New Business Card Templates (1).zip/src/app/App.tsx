import CardViewer from './components/CardViewer';

export default function App() {
  return <CardViewer />;
}
